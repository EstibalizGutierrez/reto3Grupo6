package DAOs;

import javax.swing.*;
import java.sql.PreparedStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Date;
import java.time.LocalDate;
import POJOs.Cliente;
import POJOs.Enums.idIdioma;
import POJOs.Enums.tipoUsuario;
import UTILS.Conexion;

public class ClienteDAO {
		
	private Conexion conn = new Conexion();
	private PreparedStatement statement;
	private ResultSet resultSet;
	private String clienteInsertado = "¡¡Cliente creado correctamente!!";
	private String sqlError = "No se ha podido registrar al cliente";
	
	

	/**
	 * Método para validar el login y obtener los datos del cliente
	 * @param Cliente datos
	 * @return Cliente
	 */
	public Cliente clienteLogin (Cliente datos) {
			
	Connection conexion = null;
	Cliente clienteLogueado = null; 

	String sql = "Select * from Clientes where Usuario = ? and Contrasena = ?";
			
		try {
				
			conexion = conn.getConnection();
				
			if (conexion != null) {
					
				statement = conexion.prepareStatement(sql);
				statement.setString(1, datos.getUsuario());
				statement.setString(2, datos.getContrasena());
				resultSet = statement.executeQuery();
					
				if (resultSet.next()) {
						
					// Si existe el cliente en el login lo rellenamos con sus datos de la BBDD
					
						clienteLogueado = new Cliente(
						resultSet.getString("Usuario"),
						resultSet.getString("Contrasena"),
						resultSet.getString("Nombre"),
						resultSet.getString("Apellido"),
						idIdioma.valueOf(resultSet.getString("Idioma")),
						resultSet.getDate("FechaNacimiento").toLocalDate(),
						resultSet.getDate("FechaRegistro").toLocalDate(),
						tipoUsuario.valueOf(resultSet.getString("Tipo"))
	
							);
						
						JOptionPane.showMessageDialog(null, "Login exitoso para el cliente" , clienteLogueado.getNombre(), 0);
						
						}
					
				}
				
			} catch (SQLException error) {
				
				JOptionPane.showMessageDialog(null, "Cliente no encontrado");
				
			} 
			return clienteLogueado;
			
		}

		/**
		 * Método para registrar un nuevo cliente a la BBDD
		 * @param Cliente nuevo
		 * @return boolean
		 */
		public boolean clienteInsertar (Cliente nuevo) {
			
			Connection conexion = null;
			boolean clienteValidoInsertado = false;
			String idNuevo = generarId();

			//CONSULTA SQL
			String sql = "Insert into Clientes (Usuario, Contrasena, Nombre, Apellido, Idioma, FechaNacimiento, FechaRegistro, Tipo) "
					+ 	"values (?, ?, ?, ?, ?, ?, ?, ?)";
			
			try {
				
				conexion = conn.getConnection();
				
				if (conexion != null) {
					
					statement.setString(1, idNuevo); 
		            statement.setString(2, nuevo.getUsuario());
		            statement.setString(3, nuevo.getContrasena());
		            statement.setString(4, nuevo.getNombre());
		            statement.setString(5, nuevo.getApellido());
		            statement.setString(6, nuevo.getIdioma().name());
		            statement.setDate(7, Date.valueOf(nuevo.getFechaNacimiento()));
		            statement.setDate(8, Date.valueOf(LocalDate.now()));  
		            statement.setString(9, nuevo.getTipo().name());
					
					int filas = statement.executeUpdate();//Lo hacemos para ver si se han incluido las filas en la BBDD
					
					if (filas > 0) { //con que se haya insertado al menos una fila ya sabremos que se han insertado las otras
						
						clienteValidoInsertado = true;
						
						JOptionPane.showMessageDialog(null, clienteInsertado);
						
					}
					
				}
				
			} catch (SQLException error) {
				
				JOptionPane.showMessageDialog(null, sqlError);
				
			} 
			
			return clienteValidoInsertado;
			
		}
		
		/**
		 * metodo para generar el id del cliente de manera automatica
		 * 
		 * @return String
		 */
		 
		public String generarId() {
			Connection conexion = null;
			String nuevoId = null;
			String sql = "Select idCliente from clientes order by idCliente desc limit 1"; //Sentencia para guardar el id del ultimo cliente en un String
			
			try {
				conexion = conn.getConnection();
				
				if (conexion != null) {
					
					statement = conexion.prepareStatement(sql);
					resultSet = statement.executeQuery();
					
					if (resultSet.next()) {
						String ultimoId = resultSet.getString("idCliente"); //guardamos el ultimo id en un string
						
						int num = Integer.parseInt(ultimoId.substring(2)); //Hacemos substring para OBTENER los ultimos 3 digitos y quitarnos la parte "CL" del id "CL004" (EJEMPLO)
						
						nuevoId = "CL" + String.format("%03d", num + 1); //Sumamos y lo formateamos con %03d para que solo acepte 3 numeros y que empiece por la izquierda con 0 asi como maximo solo podria existir CL999
					}
				}
			} catch (SQLException error) {

					error.printStackTrace();
			}
			
			return nuevoId;
		}

	}
	

